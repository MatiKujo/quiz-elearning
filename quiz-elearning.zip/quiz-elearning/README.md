# Platforma e-learningowa - Ocenianie quizów

Gotowy projekt Spring Boot (Java 17 + Maven). Kod jest **bardzo mocno skomentowany
po polsku**, żeby dało się go zrozumieć i obronić na egzaminie, nawet jeśli
nie znasz dobrze Javy/Springa.

## Jak uruchomić

**Wymagania:** zainstalowana Java 17+ oraz Maven (albo po prostu IntelliJ IDEA,
który ma to wbudowane).

### Opcja 1 - IntelliJ IDEA / Eclipse / VS Code
1. Otwórz cały folder `quiz-elearning` jako projekt Maven (IDE samo je rozpozna
   po pliku `pom.xml` i pobierze zależności z internetu — przy pierwszym
   otwarciu musisz mieć internet).
2. Znajdź plik `QuizApplication.java` (pakiet `pl.edu.utp.po.quiz`) i kliknij
   **Run**.
3. Wejdź w przeglądarce na: **http://localhost:8080**

### Opcja 2 - terminal
```
mvn spring-boot:run
```

## Konta testowe (tworzone automatycznie przy starcie)
| login   | hasło       | rola     |
|---------|-------------|----------|
| student | student123  | STUDENT  |
| teacher | teacher123  | TEACHER  |

## Ważne adresy
- **Aplikacja (UI):** http://localhost:8080
- **Swagger (dokumentacja REST API):** http://localhost:8080/swagger-ui/index.html
- **Konsola bazy H2 (podgląd tabel):** http://localhost:8080/h2-console
  (JDBC URL: `jdbc:h2:mem:quizdb`, user: `sa`, hasło: puste)

## Mapowanie wymagań z treści zadania na kod

| Wymaganie | Gdzie w kodzie |
|---|---|
| Baza danych: Quiz/Pytanie (treść, poprawna odpowiedź, punkty) | `domain/Quiz.java`, `domain/Question.java` |
| Baza danych: Wynik (id użytkownika, zdobyte punkty) | `domain/Result.java` |
| Widok rozwiązywania quizu | `web/QuizWebController.java` (GET `/quiz/{id}`) + `templates/quiz-solve.html` |
| Widok podsumowania z wynikiem | `web/QuizWebController.java` (POST `/quiz/{id}/solve`) + `templates/quiz-summary.html` |
| Algorytm wyliczania oceny (punkty ujemne, próg >50%) | `service/ScoreCalculator.java` |
| REST + Swagger: POST zwracający wynik procentowy | `rest/QuizRestController.java` (`POST /api/quizzes/{id}/submit`) |
| Security: tylko zalogowani studenci wysyłają odpowiedzi | `config/SecurityConfig.java` + `@PreAuthorize("hasRole('STUDENT')")` |
| Security: nauczyciel widzi wyniki wszystkich | `web/TeacherWebController.java`, `rest/ResultRestController.java` (rola TEACHER) |
| Test kalkulatora punktacji i progu zaliczeniowego | `src/test/.../service/ScoreCalculatorTest.java` |

## Zasady punktacji (ScoreCalculator)
- poprawna odpowiedź → **+pełne punkty** za pytanie (domyślnie 1 pkt)
- brak odpowiedzi → **0 punktów** (bez kary)
- zła odpowiedź → **-50% punktów** za to pytanie (np. -0.5 przy pytaniu za 1 pkt)
- wynik końcowy nie może spaść poniżej 0
- **próg zaliczenia: wynik musi być WIĘKSZY niż 50%** (dokładnie 50% nie zalicza)

## Jak przetestować REST API (Swagger)
1. Wejdź na http://localhost:8080/swagger-ui/index.html
2. Kliknij **Authorize** i zaloguj się jako `student` / `student123`
   (HTTP Basic Auth skonfigurowany w `SecurityConfig`).
3. Rozwiń `POST /api/quizzes/{id}/submit`, kliknij "Try it out",
   ustaw `id = 1` i wyślij np. takie body:
```json
{
  "quizId": 1,
  "answers": [
    { "questionId": 1, "selectedOptionIndex": 0 },
    { "questionId": 2, "selectedOptionIndex": 1 },
    { "questionId": 3, "selectedOptionIndex": 2 },
    { "questionId": 4, "selectedOptionIndex": 2 }
  ]
}
```
4. W odpowiedzi dostaniesz JSON z polami `score`, `maxScore`, `percentage`, `passed`.

(Numery `questionId` przykładowego quizu to 1,2,3,4 - zobacz je też w
konsoli H2 w tabeli `question`, albo po prostu wejdź na `/quiz/1` w UI jako student.)

## Struktura projektu (najważniejsze pakiety)
```
pl.edu.utp.po.quiz
 ├─ domain      -> encje bazodanowe (Quiz, Question, Result, AppUser, RoleEnum)
 ├─ repository  -> interfejsy JPA (dostęp do bazy danych)
 ├─ dto         -> obiekty do przesyłania danych (formularz / JSON)
 ├─ service     -> logika biznesowa (ScoreCalculator, QuizService)
 ├─ security    -> AppUserDetailsService (logowanie na podstawie bazy danych)
 ├─ config      -> SecurityConfig, DataLoader (dane startowe), OpenApiConfig
 ├─ web         -> kontrolery MVC zwracające widoki HTML
 └─ rest        -> kontrolery REST zwracające JSON (Swagger)
```

## Uruchomienie testów
```
mvn test
```
Sprawdza `ScoreCalculatorTest` - m.in. że dokładnie 50% NIE zalicza quizu,
że złe odpowiedzi nie potrafią zejść poniżej 0 punktów, itd.
