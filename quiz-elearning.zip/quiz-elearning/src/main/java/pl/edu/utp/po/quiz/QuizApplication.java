package pl.edu.utp.po.quiz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * ============================================================================
 *  KLASA STARTOWA APLIKACJI.
 *  To jest "main" - stad wszystko sie zaczyna. Adnotacja @SpringBootApplication
 *  mowi Springowi: "przeskanuj caly pakiet pl.edu.utp.po.quiz i wszystkie
 *  podpakiety, znajdz wszystkie @Component/@Service/@Controller/@Repository
 *  i zbuduj z nich dzialajaca aplikacje".
 *
 *  Zeby uruchomic caly projekt:
 *   1) Kliknij prawym na ten plik w IDE -> Run 'QuizApplication'
 *      LUB w terminalu: mvn spring-boot:run
 *   2) Wejdz w przegladarce na: http://localhost:8080
 *
 *  Konta testowe (tworzone automatycznie przy starcie przez DataLoader):
 *   - student / student123   (rola STUDENT - rozwiazuje quizy)
 *   - teacher / teacher123   (rola TEACHER - widzi wyniki wszystkich)
 *
 *  Swagger (dokumentacja REST API):
 *   http://localhost:8080/swagger-ui/index.html
 *
 *  Konsola bazy H2 (podglad tabel w bazie danych):
 *   http://localhost:8080/h2-console
 *   JDBC URL: jdbc:h2:mem:quizdb , user: sa , haslo: (puste)
 * ============================================================================
 */
@SpringBootApplication
public class QuizApplication {

    public static void main(String[] args) {
        // To jedno polecenie odpala caly serwer (Tomcat), konfiguruje baze danych,
        // rejestruje kontrolery, security itd.
        SpringApplication.run(QuizApplication.class, args);
    }
}
