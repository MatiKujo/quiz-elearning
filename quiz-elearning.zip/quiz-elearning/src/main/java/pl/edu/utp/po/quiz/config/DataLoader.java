package pl.edu.utp.po.quiz.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import pl.edu.utp.po.quiz.domain.AppUser;
import pl.edu.utp.po.quiz.domain.Question;
import pl.edu.utp.po.quiz.domain.Quiz;
import pl.edu.utp.po.quiz.domain.RoleEnum;
import pl.edu.utp.po.quiz.repository.QuizRepository;
import pl.edu.utp.po.quiz.repository.UserRepository;

import java.util.List;

/**
 * ============================================================================
 * DATA LOADER - klasa, ktora wykonuje sie AUTOMATYCZNIE raz, zaraz po starcie
 * aplikacji (bo implementuje CommandLineRunner, a jest oznaczona @Component -
 * Spring sam ja znajdzie i wywola metode run()).
 *
 * Po co to jest?
 * Baza H2 dziala "w pamieci" (znika po zatrzymaniu aplikacji), wiec za kazdym
 * razem trzeba ja od nowa wypelnic przykladowymi danymi: kontami uzytkownikow
 * i przykladowym quizem z pytaniami - zeby po odpaleniu projektu od razu
 * dalo sie kliknac i przetestowac dzialanie (bez recznego wypelniania bazy).
 * ============================================================================
 */
@Component
public class DataLoader implements CommandLineRunner {

    private final UserRepository userRepository;
    private final QuizRepository quizRepository;
    private final PasswordEncoder passwordEncoder;

    public DataLoader(UserRepository userRepository,
                       QuizRepository quizRepository,
                       PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.quizRepository = quizRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        seedUsers();
        seedQuiz();
    }

    private void seedUsers() {
        // Sprawdzamy, czy uzytkownicy juz istnieja - zabezpieczenie na wypadek,
        // gdyby kiedys zmieniono baze na "trwala" zamiast "w pamieci".
        if (userRepository.count() > 0) {
            return;
        }

        // Konto STUDENTA: login=student, haslo=student123
        AppUser student = new AppUser(
                "student",
                passwordEncoder.encode("student123"),
                RoleEnum.STUDENT
        );

        // Konto NAUCZYCIELA: login=teacher, haslo=teacher123
        AppUser teacher = new AppUser(
                "teacher",
                passwordEncoder.encode("teacher123"),
                RoleEnum.TEACHER
        );

        userRepository.save(student);
        userRepository.save(teacher);
    }

    private void seedQuiz() {
        if (quizRepository.count() > 0) {
            return;
        }

        Quiz quiz = new Quiz("Podstawy Javy");

        quiz.addQuestion(new Question(
                "Ktory z ponizszych typow jest TYPEM PROSTYM (prymitywnym) w Javie?",
                List.of("int", "Integer", "String", "ArrayList"),
                0,   // poprawna odpowiedz: "int" (indeks 0)
                1.0  // 1 punkt za poprawna odpowiedz
        ));

        quiz.addQuestion(new Question(
                "Ktore slowo kluczowe sluzy do dziedziczenia klasy w Javie?",
                List.of("implements", "extends", "inherits", "super"),
                1,   // poprawna odpowiedz: "extends"
                1.0
        ));

        quiz.addQuestion(new Question(
                "Ktora kolekcja w Javie NIE pozwala na duplikaty elementow?",
                List.of("List", "Set", "Map.values()", "Queue"),
                1,   // poprawna odpowiedz: "Set"
                1.0
        ));

        quiz.addQuestion(new Question(
                "Jakiej adnotacji uzywamy w Spring, aby oznaczyc klase jako kontroler REST?",
                List.of("@Service", "@Repository", "@RestController", "@Component"),
                2,   // poprawna odpowiedz: "@RestController"
                1.0
        ));

        quizRepository.save(quiz);
    }
}
