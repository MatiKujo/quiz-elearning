package pl.edu.utp.po.quiz.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Drobna konfiguracja Swaggera (biblioteka springdoc-openapi wykrywa
 * kontrolery @RestController AUTOMATYCZNIE - to jest tylko "ladny naglowek"
 * dla wygenerowanej dokumentacji).
 *
 * Po uruchomieniu aplikacji dokumentacje znajdziesz pod adresem:
 *   http://localhost:8080/swagger-ui/index.html
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI quizOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Quiz e-learning API")
                        .description("REST API platformy e-learningowej do oceniania quizow. " +
                                "Endpoint POST /api/quizzes/{id}/submit przyjmuje odpowiedzi studenta " +
                                "i zwraca wynik procentowy.")
                        .version("1.0.0"));
    }
}
