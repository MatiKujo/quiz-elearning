package pl.edu.utp.po.quiz.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/**
 * ============================================================================
 * KONFIGURACJA BEZPIECZENSTWA (Spring Security) - odpowiada na wymaganie
 * z tresci zadania: "Tylko zalogowani studenci moga wyslac odpowiedzi.
 * Nauczyciel widzi wyniki wszystkich."
 *
 * @EnableWebSecurity     - wlacza mechanizmy Spring Security w aplikacji
 * @EnableMethodSecurity  - pozwala uzywac adnotacji @PreAuthorize(...)
 *                          bezposrednio na metodach kontrolerow REST
 *                          (dodatkowa, "druga linia obrony" oprocz regul URL)
 * ============================================================================
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    /**
     * Bean odpowiedzialny za szyfrowanie hasel algorytmem BCrypt.
     * Uzywany zarowno przy zakladaniu kont (DataLoader), jak i przy
     * sprawdzaniu hasla podczas logowania (automatycznie przez Springa).
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Glowna konfiguracja regul bezpieczenstwa - kto, do czego ma dostep.
     */
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                // Zasoby publiczne - dostepne bez logowania:
                // strona logowania, pliki statyczne (css), konsola bazy H2,
                // oraz Swagger (dokumentacja API - wygodnie miec ja jawna do wgladu)
                .requestMatchers(
                        "/login",
                        "/css/**",
                        "/js/**",
                        "/h2-console/**",
                        "/swagger-ui/**",
                        "/swagger-ui.html",
                        "/v3/api-docs/**"
                ).permitAll()

                // Panel/API nauczyciela - TYLKO rola TEACHER
                .requestMatchers("/teacher/**", "/api/results/**").hasRole("TEACHER")

                // Rozwiazywanie quizow (widok + REST submit) - TYLKO rola STUDENT
                .requestMatchers("/quiz/**", "/api/quizzes/**").hasRole("STUDENT")

                // Wszystko inne wymaga chocby bycia zalogowanym
                .anyRequest().authenticated()
            )
            // Logowanie formularzem HTML (wlasny widok login.html) - dla uzytkownika
            // korzystajacego z przegladarki (widok quiz-solve / teacher-results)
            .formLogin(form -> form
                    .loginPage("/login")
                    .defaultSuccessUrl("/", true)
                    .permitAll()
            )
            .logout(logout -> logout.permitAll())
            // HTTP Basic - dodatkowa metoda logowania, wygodna przy testowaniu
            // REST API np. przez Swagger UI / Postmana (login+haslo w naglowku)
            .httpBasic(Customizer.withDefaults())
            // Wylaczamy CSRF dla /api/** (typowe REST API bez sesji-ciasteczek
            // "przegladarkowych" w sensie formularzy) i dla konsoli H2 (potrzebne
            // do dzialania ramki H2 w przegladarce)
            .csrf(csrf -> csrf.ignoringRequestMatchers("/api/**", "/h2-console/**"))
            // Konsola H2 dziala we "wlasnej ramce" (frame) - domyslnie Spring
            // Security tego zabrania, tutaj to jawnie odblokowujemy
            .headers(headers -> headers.frameOptions(frame -> frame.disable()));

        return http.build();
    }
}
