package pl.edu.utp.po.quiz.domain;

import jakarta.persistence.*;

/**
 * ============================================================================
 * ENCJA UZYTKOWNIKA (do logowania).
 * @Entity          -> mowi Hibernate/JPA, ze ta klasa ma odpowiadac tabeli w bazie
 * @Id + @GeneratedValue -> klucz glowny generowany automatycznie (auto-increment)
 *
 * Kazdy wiersz w tabeli app_user to jeden uzytkownik: student albo nauczyciel.
 * Haslo trzymamy zaszyfrowane (BCrypt), NIGDY jawnym tekstem.
 * ============================================================================
 */
@Entity
@Table(name = "app_user")
public class AppUser {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // login uzytkownika - musi byc unikalny (nie moze byc dwoch takich samych)
    @Column(unique = true, nullable = false)
    private String username;

    // haslo ZASZYFROWANE (BCrypt) - nigdy nie trzymamy hasla w czystej postaci
    @Column(nullable = false)
    private String password;

    // rola: STUDENT albo TEACHER - decyduje co uzytkownik moze robic
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RoleEnum role;

    // Pusty konstruktor jest WYMAGANY przez JPA/Hibernate (tworzy obiekty "za kulisami")
    public AppUser() {
    }

    public AppUser(String username, String password, RoleEnum role) {
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // ============ GETTERY I SETTERY (Spring/Hibernate uzywaja ich automatycznie) ============

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public RoleEnum getRole() {
        return role;
    }

    public void setRole(RoleEnum role) {
        this.role = role;
    }
}
