package pl.edu.utp.po.quiz.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================================
 * ENCJA PYTANIE ("Pytanie" z tresci zadania).
 * Pole zgodne z wymaganiami: tresc, poprawna odpowiedz, punkty.
 * Dodatkowo trzymamy liste mozliwych opcji (bo to test WIELOKROTNEGO WYBORU,
 * czyli student wybiera jedna z kilku odpowiedzi na liscie).
 *
 * @ManyToOne do Quiz - wiele pytan nalezy do jednego quizu.
 * ============================================================================
 */
@Entity
@Table(name = "question")
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Tresc pytania, np. "Ktory z ponizszych typow jest typem prostym w Javie?"
    @Column(length = 1000, nullable = false)
    private String content;

    // Lista mozliwych odpowiedzi do wyboru, np. ["int", "Integer", "String", "ArrayList"]
    // @ElementCollection - to NIE jest osobna encja, tylko prosta lista Stringow
    // trzymana w dodatkowej tabeli pomocniczej "question_options".
    // @OrderColumn zapewnia, ze kolejnosc opcji (indeksy 0,1,2,3...) jest zachowana.
    @ElementCollection
    @CollectionTable(name = "question_options", joinColumns = @JoinColumn(name = "question_id"))
    @OrderColumn(name = "option_index")
    @Column(name = "option_text")
    private List<String> options = new ArrayList<>();

    // Indeks (0-based) POPRAWNEJ odpowiedzi w liscie "options".
    // np. jesli correctOptionIndex = 0, to poprawna jest options.get(0)
    @Column(nullable = false)
    private int correctOptionIndex;

    // Ile punktow dostaje student za POPRAWNA odpowiedz na to pytanie (np. 1.0)
    @Column(nullable = false)
    private double points;

    // Do jakiego quizu nalezy to pytanie. @JsonIgnore zapobiega niekonczonej
    // petli przy ewentualnej serializacji do JSON (Question -> Quiz -> Question -> ...)
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "quiz_id")
    @JsonIgnore
    private Quiz quiz;

    public Question() {
    }

    public Question(String content, List<String> options, int correctOptionIndex, double points) {
        this.content = content;
        this.options = options;
        this.correctOptionIndex = correctOptionIndex;
        this.points = points;
    }

    // ============ GETTERY I SETTERY ============

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public List<String> getOptions() {
        return options;
    }

    public void setOptions(List<String> options) {
        this.options = options;
    }

    public int getCorrectOptionIndex() {
        return correctOptionIndex;
    }

    public void setCorrectOptionIndex(int correctOptionIndex) {
        this.correctOptionIndex = correctOptionIndex;
    }

    public double getPoints() {
        return points;
    }

    public void setPoints(double points) {
        this.points = points;
    }

    public Quiz getQuiz() {
        return quiz;
    }

    public void setQuiz(Quiz quiz) {
        this.quiz = quiz;
    }
}
