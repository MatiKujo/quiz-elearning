package pl.edu.utp.po.quiz.domain;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================================
 * ENCJA QUIZ - jeden test skladajacy sie z wielu pytan (Question).
 *
 * @OneToMany(mappedBy = "quiz") -> jeden Quiz ma wiele Question.
 * cascade = ALL   -> zapisujac/kasujac Quiz, zapisujemy/kasujemy tez jego pytania.
 * orphanRemoval   -> jesli usuniemy pytanie z listy, samo zniknie z bazy danych.
 * ============================================================================
 */
@Entity
@Table(name = "quiz")
public class Quiz {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // Nazwa/tytul quizu, np. "Podstawy Javy"
    @Column(nullable = false)
    private String title;

    // Lista pytan nalezacych do tego quizu.
    @OneToMany(mappedBy = "quiz", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    private List<Question> questions = new ArrayList<>();

    public Quiz() {
    }

    public Quiz(String title) {
        this.title = title;
    }

    /**
     * Pomocnicza metoda - dodaje pytanie do quizu i JEDNOCZESNIE ustawia
     * powiazanie zwrotne (question.setQuiz(this)), zeby Hibernate poprawnie
     * zapisal relacje w bazie danych (bez tego mielibysmy "wiszace" pytania
     * bez przypisanego quiz_id).
     */
    public void addQuestion(Question question) {
        questions.add(question);
        question.setQuiz(this);
    }

    // ============ GETTERY I SETTERY ============

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<Question> getQuestions() {
        return questions;
    }

    public void setQuestions(List<Question> questions) {
        this.questions = questions;
    }
}
