package pl.edu.utp.po.quiz.domain;

import jakarta.persistence.*;

import java.time.LocalDateTime;

/**
 * ============================================================================
 * ENCJA WYNIK ("Wynik" z tresci zadania: id uzytkownika, zdobyte punkty).
 * Zapisuje sie jeden rekord Result za kazdym razem, gdy student wysyla
 * odpowiedzi do quizu (patrz: QuizService.submitAnswers).
 *
 * Trzymamy tu zarowno "surowe" punkty (score / maxScore) jak i wyliczony
 * procent oraz informacje czy quiz zostal zaliczony (passed) - to ulatwia
 * pozniejsze wyswietlanie wynikow nauczycielowi bez przeliczania na nowo.
 * ============================================================================
 */
@Entity
@Table(name = "result")
public class Result {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // "id uzytkownika" z tresci zadania - u nas login studenta (username)
    @Column(nullable = false)
    private String userId;

    // Ktorego quizu dotyczy ten wynik
    @Column(nullable = false)
    private Long quizId;

    // Zdobyte punkty (moze byc ulamkowe, np. 2.5, bo za zle odpowiedzi odejmujemy 0.5)
    @Column(nullable = false)
    private double score;

    // Maksymalna mozliwa liczba punktow do zdobycia w tym quizie
    @Column(nullable = false)
    private double maxScore;

    // Wynik procentowy: score / maxScore * 100
    @Column(nullable = false)
    private double percentage;

    // Czy quiz zostal zaliczony (percentage > prog zaliczenia, domyslnie 50%)
    @Column(nullable = false)
    private boolean passed;

    // Data i godzina wyslania odpowiedzi
    @Column(nullable = false)
    private LocalDateTime submittedAt;

    public Result() {
    }

    // ============ GETTERY I SETTERY ============

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getQuizId() {
        return quizId;
    }

    public void setQuizId(Long quizId) {
        this.quizId = quizId;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public double getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(double maxScore) {
        this.maxScore = maxScore;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    public boolean isPassed() {
        return passed;
    }

    public void setPassed(boolean passed) {
        this.passed = passed;
    }

    public LocalDateTime getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(LocalDateTime submittedAt) {
        this.submittedAt = submittedAt;
    }
}
