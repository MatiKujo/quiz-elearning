package pl.edu.utp.po.quiz.domain;

/**
 * Role uzytkownikow w systemie.
 * STUDENT  - moze rozwiazywac quizy i wysylac odpowiedzi.
 * TEACHER  - moze podgladac wyniki wszystkich studentow.
 */
public enum RoleEnum {
    STUDENT,
    TEACHER
}
