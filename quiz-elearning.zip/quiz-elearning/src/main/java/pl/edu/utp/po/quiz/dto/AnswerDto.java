package pl.edu.utp.po.quiz.dto;

/**
 * ============================================================================
 * DTO (Data Transfer Object) = zwykla klasa do PRZESYLANIA danych,
 * np. z formularza HTML albo z zadania REST (JSON), do serwera.
 * Nie jest to encja bazodanowa (brak @Entity) - to tylko "koperta" na dane.
 *
 * Reprezentuje JEDNA odpowiedz studenta na JEDNO pytanie.
 * ============================================================================
 */
public class AnswerDto {

    // Id pytania, ktorego dotyczy ta odpowiedz
    private Long questionId;

    // Ktora opcje (indeks 0,1,2,3...) wybral student.
    // Typ Integer (obiekt, nie int!) celowo - dzieki temu wartosc MOZE byc null,
    // co oznacza "student nie zaznaczyl zadnej odpowiedzi" (czyli "brak" z tresci
    // zadania: poprawna +1, brak 0, zla -0.5).
    private Integer selectedOptionIndex;

    public AnswerDto() {
    }

    public AnswerDto(Long questionId, Integer selectedOptionIndex) {
        this.questionId = questionId;
        this.selectedOptionIndex = selectedOptionIndex;
    }

    public Long getQuestionId() {
        return questionId;
    }

    public void setQuestionId(Long questionId) {
        this.questionId = questionId;
    }

    public Integer getSelectedOptionIndex() {
        return selectedOptionIndex;
    }

    public void setSelectedOptionIndex(Integer selectedOptionIndex) {
        this.selectedOptionIndex = selectedOptionIndex;
    }
}
