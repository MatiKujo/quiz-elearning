package pl.edu.utp.po.quiz.dto;

/**
 * DTO wyniku, ktory serwer ODSYLA do klienta po sprawdzeniu quizu:
 * - score       - zdobyte punkty (moga byc ulamkowe, np. 2.5)
 * - maxScore    - maksymalna mozliwa liczba punktow
 * - percentage  - wynik procentowy (score / maxScore * 100)
 * - passed      - czy quiz zostal zaliczony (percentage > prog, domyslnie 50%)
 *
 * To jest dokladnie to, co zwraca endpoint REST:
 * POST /api/quizzes/{id}/submit  ->  ResultDto w formacie JSON
 */
public class ResultDto {

    private double score;
    private double maxScore;
    private double percentage;
    private boolean passed;

    public ResultDto() {
    }

    public ResultDto(double score, double maxScore, double percentage, boolean passed) {
        this.score = score;
        this.maxScore = maxScore;
        this.percentage = percentage;
        this.passed = passed;
    }

    public double getScore() {
        return score;
    }

    public void setScore(double score) {
        this.score = score;
    }

    public double getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(double maxScore) {
        this.maxScore = maxScore;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    public boolean isPassed() {
        return passed;
    }

    public void setPassed(boolean passed) {
        this.passed = passed;
    }
}
