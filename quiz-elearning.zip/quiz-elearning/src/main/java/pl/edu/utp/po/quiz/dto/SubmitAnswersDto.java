package pl.edu.utp.po.quiz.dto;

import java.util.ArrayList;
import java.util.List;

/**
 * DTO reprezentujacy CALY komplet odpowiedzi wyslany przez studenta:
 * - id quizu, ktory rozwiazywal
 * - lista jego odpowiedzi (AnswerDto) na kazde pytanie
 *
 * Ten obiekt jest uzywany zarowno w formularzu HTML (widok quiz-solve.html
 * binduje sie do niego przez th:object), jak i w REST API jako body zadania
 * POST /api/quizzes/{id}/submit (przesylany jako JSON).
 */
public class SubmitAnswersDto {

    private Long quizId;

    private List<AnswerDto> answers = new ArrayList<>();

    public SubmitAnswersDto() {
    }

    public Long getQuizId() {
        return quizId;
    }

    public void setQuizId(Long quizId) {
        this.quizId = quizId;
    }

    public List<AnswerDto> getAnswers() {
        return answers;
    }

    public void setAnswers(List<AnswerDto> answers) {
        this.answers = answers;
    }
}
