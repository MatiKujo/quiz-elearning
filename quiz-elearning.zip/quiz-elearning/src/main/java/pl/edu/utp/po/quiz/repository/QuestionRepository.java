package pl.edu.utp.po.quiz.repository;

import pl.edu.utp.po.quiz.domain.Question;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repozytorium pytan - dostep do tabeli "question" w bazie danych.
 * W praktyce w tym projekcie pytania sa najczesciej pobierane "przy okazji"
 * quizu (Quiz.getQuestions()), ale repozytorium zostawiamy do ewentualnego
 * pobierania/edycji pojedynczych pytan.
 */
public interface QuestionRepository extends JpaRepository<Question, Long> {
}
