package pl.edu.utp.po.quiz.repository;

import pl.edu.utp.po.quiz.domain.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Repozytorium quizow - dostep do tabeli "quiz" w bazie danych.
 * Dzieki JpaRepository mamy gotowe: findAll(), findById(), save(), itd.
 */
public interface QuizRepository extends JpaRepository<Quiz, Long> {
}
