package pl.edu.utp.po.quiz.repository;

import pl.edu.utp.po.quiz.domain.Result;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * Repozytorium wynikow - dostep do tabeli "result" w bazie danych.
 *
 * findByUserId - zwraca wszystkie wyniki konkretnego studenta (np. gdyby
 * chcial zobaczyc swoja historie podejsc do quizow).
 * Nauczyciel (kontroler TeacherWebController / ResultRestController) korzysta
 * po prostu z findAll() odziedziczonego z JpaRepository, zeby widziec
 * WSZYSTKIE wyniki wszystkich studentow.
 */
public interface ResultRepository extends JpaRepository<Result, Long> {

    List<Result> findByUserId(String userId);
}
