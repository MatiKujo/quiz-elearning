package pl.edu.utp.po.quiz.repository;

import pl.edu.utp.po.quiz.domain.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * Repozytorium = "automatyczny DAO". Rozszerzajac JpaRepository<AppUser, Long>
 * dostajemy ZA DARMO metody typu save(), findAll(), findById(), deleteById()
 * itd. - Spring sam wygeneruje implementacje w locie, nie musimy pisac SQL.
 *
 * findByUsername - metoda "magiczna": Spring Data JPA sam odgadnie zapytanie
 * SQL na podstawie nazwy metody (SELECT * FROM app_user WHERE username = ?).
 */
public interface UserRepository extends JpaRepository<AppUser, Long> {

    Optional<AppUser> findByUsername(String username);
}
