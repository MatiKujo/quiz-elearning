package pl.edu.utp.po.quiz.rest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import pl.edu.utp.po.quiz.dto.ResultDto;
import pl.edu.utp.po.quiz.dto.SubmitAnswersDto;
import pl.edu.utp.po.quiz.service.QuizService;

import java.security.Principal;

/**
 * ============================================================================
 * KONTROLER REST - "REST + Swagger: Endpoint POST przyjmujacy odpowiedzi
 * ucznia i zwracajacy wynik procentowy" (dokladny cytat z tresci zadania).
 *
 * @RestController = @Controller + @ResponseBody -> wszystko co zwracaja
 * metody tej klasy jest AUTOMATYCZNIE zamieniane na JSON (nie na widok HTML).
 *
 * Adnotacje @Tag / @Operation to adnotacje biblioteki springdoc-openapi -
 * dzieki nim ten endpoint pojawia sie ladnie opisany w Swagger UI pod:
 * http://localhost:8080/swagger-ui/index.html
 * ============================================================================
 */
@RestController
@RequestMapping("/api/quizzes")
@Tag(name = "Quiz", description = "Rozwiazywanie quizow i sprawdzanie odpowiedzi")
public class QuizRestController {

    private final QuizService quizService;

    public QuizRestController(QuizService quizService) {
        this.quizService = quizService;
    }

    /**
     * POST /api/quizzes/{id}/submit
     *
     * Przyjmuje w ciele zapytania (JSON) liste odpowiedzi studenta,
     * liczy wynik (ScoreCalculator) i zwraca go jako JSON (ResultDto),
     * m.in. pole "percentage" - dokladnie tak jak wymaga tresc zadania.
     *
     * Przykladowe body zapytania:
     * {
     *   "quizId": 1,
     *   "answers": [
     *     { "questionId": 1, "selectedOptionIndex": 0 },
     *     { "questionId": 2, "selectedOptionIndex": 1 }
     *   ]
     * }
     *
     * @PreAuthorize("hasRole('STUDENT')") - dodatkowe zabezpieczenie NA POZIOMIE
     * METODY (oprocz reguly URL z SecurityConfig) - tylko zalogowany student
     * moze wyslac odpowiedzi, zgodnie z wymaganiem bezpieczenstwa z tresci.
     */
    @PostMapping("/{id}/submit")
    @PreAuthorize("hasRole('STUDENT')")
    @Operation(
            summary = "Wyslij odpowiedzi studenta i policz wynik",
            description = "Przyjmuje odpowiedzi ucznia na dany quiz i zwraca wynik procentowy " +
                    "oraz informacje, czy quiz zostal zaliczony (prog > 50%)."
    )
    @SecurityRequirement(name = "basicAuth")
    public ResponseEntity<ResultDto> submit(@PathVariable Long id,
                                             @RequestBody SubmitAnswersDto submitAnswersDto,
                                             Principal principal) {
        ResultDto result = quizService.submitAnswers(id, submitAnswersDto.getAnswers(), principal.getName());
        return ResponseEntity.ok(result);
    }
}
