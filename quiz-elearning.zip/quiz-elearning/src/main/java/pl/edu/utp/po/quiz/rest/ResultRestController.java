package pl.edu.utp.po.quiz.rest;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.edu.utp.po.quiz.domain.Result;
import pl.edu.utp.po.quiz.repository.ResultRepository;

import java.util.List;

/**
 * REST API dla nauczyciela - "Nauczyciel widzi wyniki wszystkich".
 * Dostep tylko dla roli TEACHER (regula URL w SecurityConfig +
 * dodatkowo @PreAuthorize ponizej jako druga linia zabezpieczenia).
 */
@RestController
@RequestMapping("/api/results")
@Tag(name = "Wyniki", description = "Podglad wynikow studentow (tylko nauczyciel)")
public class ResultRestController {

    private final ResultRepository resultRepository;

    public ResultRestController(ResultRepository resultRepository) {
        this.resultRepository = resultRepository;
    }

    @GetMapping
    @PreAuthorize("hasRole('TEACHER')")
    @Operation(summary = "Zwraca liste wynikow wszystkich studentow ze wszystkich quizow")
    public List<Result> getAllResults() {
        return resultRepository.findAll();
    }
}
