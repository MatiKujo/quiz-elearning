package pl.edu.utp.po.quiz.security;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import pl.edu.utp.po.quiz.domain.AppUser;
import pl.edu.utp.po.quiz.repository.UserRepository;

/**
 * ============================================================================
 * MOSTEK miedzy nasza baza danych (tabela app_user) a Spring Security.
 *
 * Spring Security podczas logowania woła metode loadUserByUsername(login) -
 * my musimy mu zwrocic obiekt UserDetails (login, zaszyfrowane haslo, role).
 * Reszte (porownanie hasla, sesje, ciasteczka) Spring Security robi juz sam.
 *
 * Implementujac ten interfejs "podpinamy" wlasna baze uzytkownikow zamiast
 * domyslnych, przykladowych uzytkownikow "w pamieci".
 * ============================================================================
 */
@Service
public class AppUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public AppUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        AppUser appUser = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("Nie znaleziono uzytkownika: " + username));

        // Budujemy obiekt UserDetails wymagany przez Spring Security.
        // .roles("STUDENT") automatycznie doda prefiks "ROLE_" wewnetrznie,
        // wiec w regulach bezpieczenstwa uzywamy potem hasRole("STUDENT").
        return User.builder()
                .username(appUser.getUsername())
                .password(appUser.getPassword()) // juz zaszyfrowane haslo (BCrypt)
                .roles(appUser.getRole().name())  // np. "STUDENT" albo "TEACHER"
                .build();
    }
}
