package pl.edu.utp.po.quiz.service;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import pl.edu.utp.po.quiz.domain.Quiz;
import pl.edu.utp.po.quiz.domain.Result;
import pl.edu.utp.po.quiz.dto.AnswerDto;
import pl.edu.utp.po.quiz.dto.ResultDto;
import pl.edu.utp.po.quiz.repository.QuizRepository;
import pl.edu.utp.po.quiz.repository.ResultRepository;

import java.time.LocalDateTime;
import java.util.List;

/**
 * ============================================================================
 * SERWIS - warstwa logiki biznesowej pomiedzy kontrolerami (Web/REST)
 * a repozytoriami (baza danych).
 *
 * @Service to specjalizacja @Component - Spring sam utworzy jeden obiekt
 * (singleton) tej klasy i "wstrzyknie" go tam, gdzie jest potrzebny
 * (przez konstruktor - tzw. constructor injection, zalecany sposob w Springu).
 * ============================================================================
 */
@Service
public class QuizService {

    private final QuizRepository quizRepository;
    private final ResultRepository resultRepository;
    private final ScoreCalculator scoreCalculator;

    // Konstruktor - Spring automatycznie "wstrzyknie" tu gotowe obiekty
    // (repozytoria i kalkulator), nie musimy ich recznie tworzyc przez "new".
    public QuizService(QuizRepository quizRepository,
                        ResultRepository resultRepository,
                        ScoreCalculator scoreCalculator) {
        this.quizRepository = quizRepository;
        this.resultRepository = resultRepository;
        this.scoreCalculator = scoreCalculator;
    }

    /**
     * Pobiera quiz o podanym id z bazy. Jesli nie istnieje - zwraca blad HTTP 404.
     */
    public Quiz getQuiz(Long id) {
        return quizRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Nie znaleziono quizu o id=" + id));
    }

    public List<Quiz> getAllQuizzes() {
        return quizRepository.findAll();
    }

    /**
     * Glowna metoda biznesowa: przyjmuje odpowiedzi studenta, liczy wynik
     * (ScoreCalculator), zapisuje go w bazie jako Result i zwraca ResultDto
     * (do wyswietlenia w widoku HTML albo zwrocenia jako JSON z REST API).
     *
     * @param quizId   id quizu, ktory jest rozwiazywany
     * @param answers  odpowiedzi udzielone przez studenta
     * @param username login zalogowanego studenta (bierzemy go z sesji Springa,
     *                 NIE z formularza - dzieki temu student nie moze podszyc
     *                 sie pod kogos innego)
     */
    public ResultDto submitAnswers(Long quizId, List<AnswerDto> answers, String username) {
        Quiz quiz = getQuiz(quizId);

        // 1) Liczymy wynik czystym algorytmem (latwym do przetestowania osobno)
        ScoreCalculator.ScoreResult scoreResult = scoreCalculator.calculate(quiz, answers);

        // 2) Zapisujemy "Wynik" w bazie danych (encja Result z tresci zadania)
        Result result = new Result();
        result.setUserId(username);
        result.setQuizId(quizId);
        result.setScore(scoreResult.getScore());
        result.setMaxScore(scoreResult.getMaxScore());
        result.setPercentage(scoreResult.getPercentage());
        result.setPassed(scoreResult.isPassed());
        result.setSubmittedAt(LocalDateTime.now());
        resultRepository.save(result);

        // 3) Zwracamy DTO do wyswietlenia / wyslania jako JSON
        return new ResultDto(
                scoreResult.getScore(),
                scoreResult.getMaxScore(),
                scoreResult.getPercentage(),
                scoreResult.isPassed()
        );
    }
}
