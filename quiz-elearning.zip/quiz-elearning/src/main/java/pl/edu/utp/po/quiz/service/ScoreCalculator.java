package pl.edu.utp.po.quiz.service;

import org.springframework.stereotype.Component;
import pl.edu.utp.po.quiz.domain.Question;
import pl.edu.utp.po.quiz.domain.Quiz;
import pl.edu.utp.po.quiz.dto.AnswerDto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ============================================================================
 * SERCE CALEGO ZADANIA - "Algorytm: Wyliczanie oceny koncowej z testu
 * wielokrotnego wyboru".
 *
 * Zasady punktacji (zgodnie z trescia zadania):
 *   - poprawna odpowiedz  -> + pelna liczba punktow za pytanie (question.points)
 *   - brak odpowiedzi     -> 0 punktow (student nie ryzykuje, nie traci)
 *   - zla odpowiedz       -> punkty UJEMNE, aby zniechecic do zgadywania
 *                            (przyklad z tresci: przy punktacji +1 za pytanie,
 *                             zla odpowiedz kosztuje -0.5, czyli POLOWE punktow
 *                             mozliwych do zdobycia za to pytanie)
 *
 * Wynik koncowy: procent = zdobyte_punkty / maksymalne_punkty * 100
 * Zaliczenie: procent > PASS_THRESHOLD_PERCENT (domyslnie 50%, ostra nierownosc!)
 *
 * Ta klasa jest CELOWO "czysta" (bez adnotacji @Entity, bez zaleznosci od bazy
 * danych) - dzieki temu latwo ja przetestowac w izolacji (patrz test:
 * ScoreCalculatorTest w src/test).
 * ============================================================================
 */
@Component
public class ScoreCalculator {

    // Ile procent punktow za pytanie tracimy przy ZLEJ odpowiedzi.
    // 0.5 = 50% -> dla pytania wartego 1.0 pkt, zla odpowiedz kosztuje -0.5 pkt
    // (dokladnie tak jak w przykladzie z tresci zadania).
    public static final double WRONG_ANSWER_PENALTY_RATIO = 0.5;

    // Prog zaliczenia testu - wiecej niz 50% (nierownosc OSTRA, "50% dokladnie"
    // NIE wystarcza do zaliczenia - tak wynika z zapisu "próg >50%" w tresci).
    public static final double PASS_THRESHOLD_PERCENT = 50.0;

    /**
     * Glowna metoda liczaca wynik. Przyjmuje caly Quiz (z lista pytan
     * i poprawnymi odpowiedziami) oraz liste odpowiedzi udzielonych przez
     * studenta, a zwraca obiekt ScoreResult z podsumowaniem.
     *
     * @param quiz           quiz, ktory student rozwiazywal (zrodlo prawdy
     *                       o poprawnych odpowiedziach i punktacji)
     * @param studentAnswers odpowiedzi przeslane przez studenta
     * @return wynik: punkty zdobyte, maksymalne, procent i info o zaliczeniu
     */
    public ScoreResult calculate(Quiz quiz, List<AnswerDto> studentAnswers) {

        // Zamieniamy liste odpowiedzi studenta na mape: id_pytania -> wybrany indeks.
        // Dzieki temu szybko sprawdzimy odpowiedz na kazde pytanie (bez petli w petli).
        Map<Long, Integer> answersByQuestionId = new HashMap<>();
        if (studentAnswers != null) {
            for (AnswerDto answer : studentAnswers) {
                if (answer != null && answer.getQuestionId() != null) {
                    answersByQuestionId.put(answer.getQuestionId(), answer.getSelectedOptionIndex());
                }
            }
        }

        double totalScore = 0.0;
        double maxScore = 0.0;

        // Przechodzimy po WSZYSTKICH pytaniach quizu (nie po odpowiedziach studenta!)
        // - to wazne, bo gdyby student cos pominal, dalej musimy policzyc mu 0 pkt
        // za to pytanie, a nie po prostu je zignorowac.
        for (Question question : quiz.getQuestions()) {

            maxScore += question.getPoints();

            Integer selectedIndex = answersByQuestionId.get(question.getId());

            if (selectedIndex == null) {
                // BRAK ODPOWIEDZI -> 0 punktow, nic nie dodajemy ani nie odejmujemy
                continue;
            }

            if (selectedIndex == question.getCorrectOptionIndex()) {
                // POPRAWNA ODPOWIEDZ -> pelne punkty za pytanie
                totalScore += question.getPoints();
            } else {
                // ZLA ODPOWIEDZ -> punkty ujemne (polowa punktow za pytanie)
                totalScore -= question.getPoints() * WRONG_ANSWER_PENALTY_RATIO;
            }
        }

        // Nie pozwalamy, zeby koncowy wynik spadl ponizej zera (student nie moze
        // "wyjsc na minus" z calego testu, tylko traci punkty do zera) - to
        // typowe, rozsadne zalozenie przy testach z punktami ujemnymi.
        if (totalScore < 0) {
            totalScore = 0;
        }

        double percentage = (maxScore > 0) ? (totalScore / maxScore) * 100.0 : 0.0;

        // Ostra nierownosc: dokladnie 50% NIE zalicza (wymaganie z tresci: próg >50%)
        boolean passed = percentage > PASS_THRESHOLD_PERCENT;

        return new ScoreResult(totalScore, maxScore, percentage, passed);
    }

    /**
     * Prosty, niemutowalny obiekt-wynik zwracany przez calculate().
     * Trzyma 4 wartosci potrzebne do zbudowania encji Result / ResultDto.
     */
    public static class ScoreResult {

        private final double score;
        private final double maxScore;
        private final double percentage;
        private final boolean passed;

        public ScoreResult(double score, double maxScore, double percentage, boolean passed) {
            this.score = score;
            this.maxScore = maxScore;
            this.percentage = percentage;
            this.passed = passed;
        }

        public double getScore() {
            return score;
        }

        public double getMaxScore() {
            return maxScore;
        }

        public double getPercentage() {
            return percentage;
        }

        public boolean isPassed() {
            return passed;
        }
    }
}
