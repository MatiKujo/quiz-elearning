package pl.edu.utp.po.quiz.web;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * Kontroler MVC (@Controller, NIE @RestController!) - zwraca NAZWY WIDOKOW
 * (plikow .html w src/main/resources/templates), a nie surowy JSON/tekst.
 * To wlasnie ten typ kontrolera odpowiada za "Webowe UI" z tresci zadania.
 */
@Controller
public class HomeController {

    /**
     * Strona glowna - przekierowuje w zaleznosci od ROLI zalogowanego
     * uzytkownika: nauczyciel -> lista wynikow, student -> quiz nr 1.
     * (Bez tego nauczyciel, ktory nie ma dostepu do /quiz/**, dostalby
     * blad 403 zaraz po zalogowaniu).
     */
    @GetMapping("/")
    public String home(Authentication authentication) {
        boolean isTeacher = authentication.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .anyMatch(a -> a.equals("ROLE_TEACHER"));

        if (isTeacher) {
            return "redirect:/teacher/results";
        }
        return "redirect:/quiz/1";
    }

    /**
     * Wlasny widok logowania (login.html) - podpiety w SecurityConfig
     * przez .loginPage("/login").
     */
    @GetMapping("/login")
    public String login() {
        return "login";
    }
}
