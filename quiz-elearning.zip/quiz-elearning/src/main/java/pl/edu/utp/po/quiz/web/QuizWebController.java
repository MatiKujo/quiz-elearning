package pl.edu.utp.po.quiz.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import pl.edu.utp.po.quiz.domain.Question;
import pl.edu.utp.po.quiz.domain.Quiz;
import pl.edu.utp.po.quiz.dto.AnswerDto;
import pl.edu.utp.po.quiz.dto.ResultDto;
import pl.edu.utp.po.quiz.dto.SubmitAnswersDto;
import pl.edu.utp.po.quiz.service.QuizService;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

/**
 * ============================================================================
 * KONTROLER WEBOWY (HTML) obslugujacy dwa widoki z tresci zadania:
 *  1) "Widok rozwiazywania quizu (kilka pytan z opcjami)"  -> GET  /quiz/{id}
 *  2) "Widok podsumowania z wynikiem"                       -> POST /quiz/{id}/solve
 *
 * Zabezpieczenie: caly adres /quiz/** jest dostepny TYLKO dla roli STUDENT
 * (regula ustawiona centralnie w SecurityConfig -> requestMatchers("/quiz/**")).
 * ============================================================================
 */
@Controller
public class QuizWebController {

    private final QuizService quizService;

    public QuizWebController(QuizService quizService) {
        this.quizService = quizService;
    }

    /**
     * Wyswietla formularz z pytaniami quizu (radio buttony z opcjami odpowiedzi).
     * Przygotowujemy pusty obiekt "submission" z liczba pol odpowiedzi rowna
     * liczbie pytan - dzieki temu formularz w Thymeleaf moze sie do niego
     * "podpiac" (th:field) w kolejnosci zgodnej z pytaniami.
     */
    @GetMapping("/quiz/{id}")
    public String showQuiz(@PathVariable Long id, Model model) {
        Quiz quiz = quizService.getQuiz(id);

        SubmitAnswersDto submission = new SubmitAnswersDto();
        submission.setQuizId(id);

        List<AnswerDto> answers = new ArrayList<>();
        for (Question question : quiz.getQuestions()) {
            // Z gory wpisujemy id pytania - w formularzu bedzie ono ukrytym polem
            // (hidden input), zeby po wyslaniu formularza wiedziec, ktorej
            // odpowiedzi dotyczy zaznaczony radio button.
            AnswerDto answerDto = new AnswerDto();
            answerDto.setQuestionId(question.getId());
            answers.add(answerDto);
        }
        submission.setAnswers(answers);

        model.addAttribute("quiz", quiz);
        model.addAttribute("submission", submission);
        return "quiz-solve"; // -> templates/quiz-solve.html
    }

    /**
     * Odbiera wypelniony formularz (odpowiedzi studenta), liczy wynik
     * i pokazuje widok podsumowania.
     *
     * Principal principal - to zalogowany uzytkownik (Spring Security
     * wstrzykuje go automatycznie). Uzywamy principal.getName() jako
     * "id uzytkownika" zamiast ufac jakiemukolwiek polu z formularza -
     * to zabezpiecza przed podszywaniem sie pod innego studenta.
     */
    @PostMapping("/quiz/{id}/solve")
    public String solveQuiz(@PathVariable Long id,
                             @ModelAttribute("submission") SubmitAnswersDto submission,
                             Principal principal,
                             Model model) {

        ResultDto result = quizService.submitAnswers(id, submission.getAnswers(), principal.getName());

        model.addAttribute("result", result);
        model.addAttribute("quizId", id);
        return "quiz-summary"; // -> templates/quiz-summary.html
    }
}
