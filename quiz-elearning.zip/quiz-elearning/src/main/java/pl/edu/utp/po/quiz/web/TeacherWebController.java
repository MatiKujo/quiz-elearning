package pl.edu.utp.po.quiz.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import pl.edu.utp.po.quiz.repository.ResultRepository;

/**
 * Kontroler widoku dla NAUCZYCIELA - "Nauczyciel widzi wyniki wszystkich".
 * Caly adres /teacher/** jest ograniczony do roli TEACHER w SecurityConfig.
 */
@Controller
public class TeacherWebController {

    private final ResultRepository resultRepository;

    public TeacherWebController(ResultRepository resultRepository) {
        this.resultRepository = resultRepository;
    }

    @GetMapping("/teacher/results")
    public String allResults(Model model) {
        // findAll() zwraca wyniki WSZYSTKICH studentow, ze wszystkich quizow
        model.addAttribute("results", resultRepository.findAll());
        return "teacher-results"; // -> templates/teacher-results.html
    }
}
