package pl.edu.utp.po.quiz.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import pl.edu.utp.po.quiz.domain.Question;
import pl.edu.utp.po.quiz.domain.Quiz;
import pl.edu.utp.po.quiz.dto.AnswerDto;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * ============================================================================
 * TEST KALKULATORA PUNKTACJI I PROGU ZALICZENIOWEGO
 * ("Test: Test kalkulatora punktacji i wyznaczania progu zaliczeniowego"
 * - dokladnie ten punkt z tresci zadania).
 *
 * Testujemy klase ScoreCalculator W IZOLACJI - bez uruchamiania calego
 * kontekstu Spring, bez bazy danych. To jest "czysty" test jednostkowy
 * (unit test) - tworzymy obiekty Quiz/Question recznie w pamieci ("na sztywno")
 * i sprawdzamy, czy metoda calculate() liczy poprawnie wynik.
 *
 * Jak to uruchomic:
 *   - w IDE: prawy klawisz na plik -> Run Tests
 *   - w terminalu: mvn test
 * ============================================================================
 */
class ScoreCalculatorTest {

    // Testowany obiekt - tworzymy go recznie przez "new" (nie potrzebujemy tu
    // Springa, bo ScoreCalculator nie ma zadnych zaleznosci do wstrzykniecia)
    private ScoreCalculator scoreCalculator;

    // Przykladowy quiz z 4 pytaniami, kazde warte 1 punkt.
    // Poprawne odpowiedzi: pytanie1 -> indeks 0, pytanie2 -> indeks 1,
    //                       pytanie3 -> indeks 2, pytanie4 -> indeks 0
    private Quiz quiz;
    private Question q1, q2, q3, q4;

    // @BeforeEach - ta metoda wykonuje sie PRZED KAZDYM pojedynczym testem,
    // dzieki temu kazdy test dostaje "swiezy", nie zmodyfikowany obiekt quizu.
    @BeforeEach
    void setUp() {
        scoreCalculator = new ScoreCalculator();

        quiz = new Quiz("Quiz testowy");

        q1 = new Question("Pytanie 1", List.of("A", "B", "C"), 0, 1.0);
        q1.setId(1L);
        q2 = new Question("Pytanie 2", List.of("A", "B", "C"), 1, 1.0);
        q2.setId(2L);
        q3 = new Question("Pytanie 3", List.of("A", "B", "C"), 2, 1.0);
        q3.setId(3L);
        q4 = new Question("Pytanie 4", List.of("A", "B", "C"), 0, 1.0);
        q4.setId(4L);

        quiz.setQuestions(new ArrayList<>(List.of(q1, q2, q3, q4)));
    }

    @Test
    @DisplayName("Same poprawne odpowiedzi -> 100% i zaliczony")
    void allCorrectAnswers_shouldGive100PercentAndPass() {
        List<AnswerDto> answers = List.of(
                new AnswerDto(1L, 0), // poprawna
                new AnswerDto(2L, 1), // poprawna
                new AnswerDto(3L, 2), // poprawna
                new AnswerDto(4L, 0)  // poprawna
        );

        ScoreCalculator.ScoreResult result = scoreCalculator.calculate(quiz, answers);

        assertEquals(4.0, result.getScore(), 0.0001);
        assertEquals(4.0, result.getMaxScore(), 0.0001);
        assertEquals(100.0, result.getPercentage(), 0.0001);
        assertTrue(result.isPassed());
    }

    @Test
    @DisplayName("Same zle odpowiedzi -> wynik ujemny obcinany do 0, quiz niezaliczony")
    void allWrongAnswers_shouldClampScoreToZeroAndFail() {
        List<AnswerDto> answers = List.of(
                new AnswerDto(1L, 1), // zla (poprawna to 0)
                new AnswerDto(2L, 0), // zla (poprawna to 1)
                new AnswerDto(3L, 0), // zla (poprawna to 2)
                new AnswerDto(4L, 1)  // zla (poprawna to 0)
        );

        ScoreCalculator.ScoreResult result = scoreCalculator.calculate(quiz, answers);

        // 4 zle odpowiedzi * (-0.5 pkt kazda) = -2.0, ale wynik nie moze byc ujemny
        assertEquals(0.0, result.getScore(), 0.0001);
        assertEquals(4.0, result.getMaxScore(), 0.0001);
        assertEquals(0.0, result.getPercentage(), 0.0001);
        assertFalse(result.isPassed());
    }

    @Test
    @DisplayName("Brak odpowiedzi na pytania -> 0 punktow za kazde puste pytanie (bez kary)")
    void blankAnswers_shouldGiveZeroPointsWithoutPenalty() {
        // Odpowiadamy tylko na pytanie 1 (poprawnie), reszte zostawiamy pusta
        List<AnswerDto> answers = List.of(
                new AnswerDto(1L, 0) // poprawna, reszta pytan bez odpowiedzi
        );

        ScoreCalculator.ScoreResult result = scoreCalculator.calculate(quiz, answers);

        // 1 punkt za pytanie 1, 0 punktow za pozostale 3 (brak odpowiedzi, BEZ kary)
        assertEquals(1.0, result.getScore(), 0.0001);
        assertEquals(4.0, result.getMaxScore(), 0.0001);
        assertEquals(25.0, result.getPercentage(), 0.0001);
        assertFalse(result.isPassed()); // 25% < prog 50%
    }

    @Test
    @DisplayName("Dokladnie 50% wyniku -> quiz NIEZALICZONY (prog to ostre 'wiecej niz 50%')")
    void exactlyFiftyPercent_shouldNotPass() {
        // 2 poprawne (2 pkt) i 2 bez odpowiedzi (0 pkt) z 4 mozliwych -> 2/4 = 50%
        List<AnswerDto> answers = List.of(
                new AnswerDto(1L, 0), // poprawna
                new AnswerDto(2L, 1)  // poprawna
                // pytania 3 i 4 bez odpowiedzi
        );

        ScoreCalculator.ScoreResult result = scoreCalculator.calculate(quiz, answers);

        assertEquals(2.0, result.getScore(), 0.0001);
        assertEquals(50.0, result.getPercentage(), 0.0001);
        assertFalse(result.isPassed(), "Dokladnie 50% NIE powinno zaliczac quizu (prog to '>50%')");
    }

    @Test
    @DisplayName("Wynik nieznacznie powyzej 50% -> quiz ZALICZONY")
    void justAboveFiftyPercent_shouldPass() {
        // 2 poprawne (2 pkt) + 1 zla (-0.5 pkt) + 1 bez odpowiedzi (0 pkt)
        // = 1.5 / 4 pkt = 37.5% -> to za malo, wiec zamiast tego uzyjemy innego mixu:
        // 3 poprawne (3 pkt) i 1 zla (-0.5 pkt) = 2.5 / 4 = 62.5% > 50%
        List<AnswerDto> answers = List.of(
                new AnswerDto(1L, 0), // poprawna
                new AnswerDto(2L, 1), // poprawna
                new AnswerDto(3L, 2), // poprawna
                new AnswerDto(4L, 1)  // zla (poprawna to 0)
        );

        ScoreCalculator.ScoreResult result = scoreCalculator.calculate(quiz, answers);

        assertEquals(2.5, result.getScore(), 0.0001);
        assertEquals(62.5, result.getPercentage(), 0.0001);
        assertTrue(result.isPassed());
    }

    @Test
    @DisplayName("Pusta lista odpowiedzi studenta -> 0 punktow, quiz niezaliczony")
    void emptyAnswerList_shouldGiveZeroScore() {
        ScoreCalculator.ScoreResult result = scoreCalculator.calculate(quiz, List.of());

        assertEquals(0.0, result.getScore(), 0.0001);
        assertEquals(4.0, result.getMaxScore(), 0.0001);
        assertEquals(0.0, result.getPercentage(), 0.0001);
        assertFalse(result.isPassed());
    }
}
